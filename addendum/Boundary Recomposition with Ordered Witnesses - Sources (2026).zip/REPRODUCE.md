# Boundary Recomposition with Ordered Witnesses: reproduction sources

These sources accompany the addendum to *Severance Defect and the Binding Functional*, DOI 10.17605/OSF.IO/5VJMR.

## Contents and limits

The manuscript, formal/ClaimA.lean, formal/PINS.json and the unchanged runtime/TECTONICA-source-preview.zip are included. MANIFEST.json lists every other file and every member of the nested archive, with byte sizes and SHA-256 values. The manifest does not hash itself. The PDF, upstream projects and internal working records are excluded.

The formal source establishes contraction and expansion of raw directed walks for an isolated directed chain in a graph with at most one edge per ordered vertex pair. Its construction preserves ordered window traces, checked costs and spans, prefix budgets and predicates of those traces. First-arrival endpoint conditions are treated separately. This proof does not establish equivalence with every runtime operation, payload-type validation, arbitrary attachment, physical duration, infinite continuation or whole-system identity.

The runtime archive contains seven source overlay files, its manifest and its recipe. It requires the recorded TECTONICA base and four unchanged pinned dependencies; their bodies are not enclosed. Network access and availability of the pinned Git objects, toolchain and Mathlib cache are requirements of the instructions below.

## Formal reproduction

Use Git and the Lean toolchain manager elan. From this extracted Sources directory:

```text
git clone https://github.com/leanprover-community/mathlib4.git mathlib4
cd mathlib4
git checkout --detach c55e6e786f49471c72fbddbec5415808896aec1e
elan toolchain install leanprover/lean4:v4.35.0-rc3
lake env lean --version
lake exe cache get
lake env lean ../formal/ClaimA.lean
```

Confirm that the version command names Lean 4.35.0-rc3. The checked-out Mathlib lean-toolchain and Lake manifest govern its project and transitive dependencies. The supplied source includes its own #print axioms commands: inspect the compiler diagnostics and axiom dependencies, including any occurrence of sorryAx. The source, environment and diagnostics are distinct reproducibility inputs. This recipe reuses that existing Mathlib project; it introduces no replacement Lake configuration.

## Runtime reproduction

Return to the extracted Sources directory and unpack the nested archive:

```text
python -m zipfile -e runtime/TECTONICA-source-preview.zip source-preview
```

Follow source-preview/REPRODUCE.md in full. It specifies the TECTONICA Git base eba17fdc66f287121bc8935ede80c7838b2f06da, recursive initialization of the four pinned dependencies, verification and application of the seven overlay files, and the complete normal and optimized execution commands. The nested manifest records their exact pins and source hashes. Keep the dedicated dependency trees clean, including ignored and untracked files, and keep logs outside layers/.

Folded window span differs from the IE traversal count. Refusal of a complete endpoint route differs from global XV non-nestability. Fixed nonnegative total cost determines final budget, while order can change the first crossing. These examples do not establish arbitrary gluing or a whole-system Identity witness.