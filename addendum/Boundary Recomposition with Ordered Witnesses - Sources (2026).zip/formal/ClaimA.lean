import Mathlib.Data.Rat.Defs

import Mathlib.Tactic



namespace ClaimA



structure Window where

  cost : ℚ

  span : Nat

  nonneg : 0 ≤ cost

  positive : 0 < span



def burden (t : List Window) : ℚ := (t.map Window.cost).sum

def duration (t : List Window) : Nat := (t.map Window.span).sum

def budget (C : ℚ) (t : List Window) (j : Nat) : ℚ := C - burden (t.take j)



inductive Walk {V : Type} (E : V → V → Type) : V → V → Type where

  | nil (u : V) : Walk E u u

  | cons {u v w : V} (e : E u v) (p : Walk E v w) : Walk E u w



def walkLength {V : Type} {E : V → V → Type} {u v : V} : Walk E u v → Nat

  | .nil _ => 0

  | .cons _ p => walkLength p + 1



variable {V : Type} {E : V → V → Type} {a b : V}



inductive FoldEdge (E : V → V → Type) (a b : V) : V → V → Type where

  | exterior {u v : V} (e : E u v) : FoldEdge E a b u v

  | macro : FoldEdge E a b a b



inductive SplitEdge (E : V → V → Type) (a b : V) : Option V → Option V → Type where

  | exterior {u v : V} (e : E u v) : SplitEdge E a b (some u) (some v)

  | enter : SplitEdge E a b (some a) none

  | leave : SplitEdge E a b none (some b)



def contract {u v : V} : Walk (SplitEdge E a b) (some u) (some v) → Walk (FoldEdge E a b) u v

  | .nil _ => .nil _

  | .cons (.exterior e) p => .cons (.exterior e) (contract p)

  | .cons .enter (.cons .leave p) => .cons .macro (contract p)



def expand {u v : V} : Walk (FoldEdge E a b) u v → Walk (SplitEdge E a b) (some u) (some v)

  | .nil _ => .nil _

  | .cons (.exterior e) p => .cons (.exterior e) (expand p)

  | .cons .macro p => .cons .enter (.cons .leave (expand p))



theorem contract_expand {u v : V} (p : Walk (FoldEdge E a b) u v) : contract (expand p) = p := by

  induction p with

  | nil => simp [contract, expand]

  | cons e p ih => cases e <;> simp [expand, contract, ih]



theorem expand_contract_by_length (n : Nat) :

    ∀ {u v : V} (p : Walk (SplitEdge E a b) (some u) (some v)),

      walkLength p ≤ n → expand (contract p) = p := by

  induction n with

  | zero =>

    intro u v p hp

    cases p with

    | nil => simp [contract, expand]

    | cons e q => simp [walkLength] at hp

  | succ n ih =>

    intro u v p hp

    cases p with

    | nil => simp [contract, expand]

    | cons e q =>

      cases e with

      | exterior e =>

        simp only [contract, expand]

        congr 1

        apply ih q

        simp only [walkLength] at hp

        omega

      | enter =>

        cases q with

        | cons e r =>

          cases e

          simp only [contract, expand]

          congr 2

          apply ih r

          simp only [walkLength] at hp

          omega



theorem expand_contract {u v : V} (p : Walk (SplitEdge E a b) (some u) (some v)) :

    expand (contract p) = p := expand_contract_by_length (walkLength p) p (Nat.le_refl _)



-- Every raw exterior-to-exterior walk factors; no block grammar is a premise.

theorem route_factorization {u v : V} (p : Walk (SplitEdge E a b) (some u) (some v)) :

    ∃ q : Walk (FoldEdge E a b) u v, expand q = p := ⟨contract p, expand_contract p⟩



def trace {W : Type} {F : W → W → Type} (lab : {u v : W} → F u v → List Window) :

    {u v : W} → Walk F u v → List Window

  | _, _, .nil _ => []

  | _, _, .cons e p => lab e ++ trace lab p



def foldedLabel (lab : {u v : V} → E u v → List Window) (left right : List Window) :

    {u v : V} → FoldEdge E a b u v → List Window

  | _, _, .exterior e => lab e

  | _, _, .macro => left ++ right



def splitLabel (lab : {u v : V} → E u v → List Window) (left right : List Window) :

    {u v : Option V} → SplitEdge E a b u v → List Window

  | _, _, .exterior e => lab e

  | _, _, .enter => left

  | _, _, .leave => right



theorem expansion_trace (lab : {u v : V} → E u v → List Window) (left right : List Window)

    {u v : V} (p : Walk (FoldEdge E a b) u v) :

    trace (splitLabel lab left right) (expand p) = trace (foldedLabel lab left right) p := by

  induction p with

  | nil => simp [expand, trace]

  | cons e p ih => cases e <;> simp [expand, trace, splitLabel, foldedLabel, ih, List.append_assoc]





theorem contraction_trace (lab : {u v : V} → E u v → List Window) (left right : List Window)

    {u v : V} (p : Walk (SplitEdge E a b) (some u) (some v)) :

    trace (foldedLabel lab left right) (contract p) = trace (splitLabel lab left right) p := by

  rw [← expansion_trace lab left right (contract p), expand_contract]



theorem accounting (lab : {u v : V} → E u v → List Window) (left right : List Window)

    {u v : V} (p : Walk (SplitEdge E a b) (some u) (some v)) (C : ℚ) (j : Nat) :

    burden (trace (foldedLabel lab left right) (contract p)) = burden (trace (splitLabel lab left right) p) ∧

    duration (trace (foldedLabel lab left right) (contract p)) = duration (trace (splitLabel lab left right) p) ∧

    budget C (trace (foldedLabel lab left right) (contract p)) j = budget C (trace (splitLabel lab left right) p) j := by

  rw [contraction_trace]

  exact ⟨rfl, rfl, rfl⟩



theorem trace_predicate (lab : {u v : V} → E u v → List Window) (left right : List Window)

    {u v : V} (p : Walk (SplitEdge E a b) (some u) (some v)) (P : List Window → Prop) :

    P (trace (foldedLabel lab left right) (contract p)) ↔ P (trace (splitLabel lab left right) p) := by

  rw [contraction_trace]



-- One serial refinement expressed again as a graph with one distinguished edge.

inductive Extra (F : V → V → Type) (x : V) : Option V → Option V → Type where

  | old {u v : V} (e : F u v) : Extra F x (some u) (some v)

  | initial : Extra F x (some x) none



def relabel {u v : Option V} : SplitEdge E a b u v → FoldEdge (Extra E a) none (some b) u v

  | .exterior e => .exterior (.old e)

  | .enter => .exterior .initial

  | .leave => .macro



def unlabel {u v : Option V} : FoldEdge (Extra E a) none (some b) u v → SplitEdge E a b u v

  | .exterior (.old e) => .exterior e

  | .exterior .initial => .enter

  | .macro => .leave



def mapWalk {W : Type} {F G : W → W → Type} (f : {u v : W} → F u v → G u v) :

    {u v : W} → Walk F u v → Walk G u v

  | _, _, .nil u => .nil u

  | _, _, .cons e p => .cons (f e) (mapWalk f p)



theorem map_unlabel_relabel {u v : Option V} (p : Walk (SplitEdge E a b) u v) :

    mapWalk unlabel (mapWalk relabel p) = p := by

  induction p with

  | nil => rfl

  | cons e p ih => cases e <;> simp [mapWalk, relabel, unlabel, ih]



theorem map_relabel_unlabel {u v : Option V} (p : Walk (FoldEdge (Extra E a) none (some b)) u v) :

    mapWalk relabel (mapWalk unlabel p) = p := by

  induction p with

  | nil => rfl

  | cons e p ih =>

    cases e with

    | exterior e => cases e <;> simp [mapWalk, relabel, unlabel, ih]

    | «macro» => simp [mapWalk, relabel, unlabel, ih]



def nextExpand {u v : V} (p : Walk (FoldEdge E a b) u v) := mapWalk relabel (expand p)

def nextContract {u v : V} (p : Walk (FoldEdge (Extra E a) none (some b)) (some u) (some v)) :=

  contract (mapWalk unlabel p)



theorem next_contract_expand {u v : V} (p : Walk (FoldEdge E a b) u v) :

    nextContract (nextExpand p) = p := by

  unfold nextContract nextExpand

  rw [map_unlabel_relabel, contract_expand]



theorem next_expand_contract {u v : V}

    (p : Walk (FoldEdge (Extra E a) none (some b)) (some u) (some v)) :

    nextExpand (nextContract p) = p := by

  unfold nextContract nextExpand

  rw [expand_contract, map_relabel_unlabel]



-- Arbitrary finite chain length. n fresh vertices, n+1 directed chain edges.

def Carrier (V : Type) : Nat → Type

  | 0 => V

  | n+1 => Option (Carrier V n)



def liftVertex (u : V) : (n : Nat) → Carrier V n

  | 0 => u

  | n+1 => some (liftVertex u n)



def lastSource (a : V) : (n : Nat) → Carrier V n

  | 0 => a

  | _+1 => none



def Ordinary (E : V → V → Type) (a : V) : (n : Nat) → Carrier V n → Carrier V n → Type

  | 0 => E

  | n+1 => Extra (Ordinary E a n) (lastSource a n)



def SerialEdge (E : V → V → Type) (a b : V) (n : Nat) :=

  FoldEdge (Ordinary E a n) (lastSource a n) (liftVertex b n)



attribute [reducible] Carrier liftVertex lastSource Ordinary SerialEdge



def serialExpand {u v : V} (p : Walk (FoldEdge E a b) u v) :

    (n : Nat) → Walk (SerialEdge E a b n) (liftVertex u n) (liftVertex v n)

  | 0 => p

  | n+1 => nextExpand (serialExpand p n)



def serialContract {u v : V} : (n : Nat) →

    Walk (SerialEdge E a b n) (liftVertex u n) (liftVertex v n) → Walk (FoldEdge E a b) u v

  | 0, p => p

  | n+1, p => serialContract n (nextContract p)



theorem serial_contract_expand {u v : V} (p : Walk (FoldEdge E a b) u v) (n : Nat) :

    serialContract n (serialExpand p n) = p := by

  induction n with

  | zero => rfl

  | succ n ih => simp only [serialContract, serialExpand, next_contract_expand]; exact ih



theorem serial_expand_contract {u v : V} (n : Nat)

    (p : Walk (SerialEdge E a b n) (liftVertex u n) (liftVertex v n)) :

    serialExpand (serialContract n p) n = p := by

  induction n with

  | zero => rfl

  | succ n ih =>

    simp only [serialContract, serialExpand]

    rw [ih, next_expand_contract]



theorem all_raw_serial_routes_factor {u v : V} (n : Nat)

    (p : Walk (SerialEdge E a b n) (liftVertex u n) (liftVertex v n)) :

    ∃ q : Walk (FoldEdge E a b) u v, serialExpand q n = p :=

  ⟨serialContract n p, serial_expand_contract n p⟩



-- Full ordered labels for each refinement stage; zero-length labels here are

-- harmless algebraically, and nonempty interface data is imposed separately.

def piece (ts : List (List Window)) : Nat → List Window

  | 0 => ts.headD []

  | n+1 => piece ts.tail n



def suffix (ts : List (List Window)) : Nat → List Window

  | 0 => ts.flatten

  | n+1 => suffix ts.tail n



theorem suffix_split (ts : List (List Window)) (n : Nat) :

    suffix ts n = piece ts n ++ suffix ts (n+1) := by

  induction n generalizing ts with

  | zero => cases ts <;> simp [suffix, piece]

  | succ n ih => simpa [suffix, piece] using ih ts.tail



def extraLabel (lab : {u v : V} → E u v → List Window) (t : List Window) :

    {u v : Option V} → Extra E a u v → List Window

  | _, _, .old e => lab e

  | _, _, .initial => t



def ordinaryLabel (lab : {u v : V} → E u v → List Window) (ts : List (List Window)) :

    (n : Nat) → {u v : Carrier V n} → Ordinary E a n u v → List Window

  | 0 => lab

  | n+1 => extraLabel (ordinaryLabel lab ts n) (piece ts n)



def serialLabel (lab : {u v : V} → E u v → List Window) (ts : List (List Window)) (n : Nat) :

    {u v : Carrier V n} → SerialEdge E a b n u v → List Window :=

  foldedLabel (ordinaryLabel lab ts n) (suffix ts n) []



theorem next_trace (lab : {u v : V} → E u v → List Window) (left right : List Window)

    {u v : V} (p : Walk (FoldEdge E a b) u v) :

    trace (foldedLabel (extraLabel lab left) right []) (nextExpand p) =

      trace (foldedLabel lab left right) p := by

  induction p with

  | nil => rfl

  | cons e p ih =>

    cases e with

    | exterior e => simpa [nextExpand, expand, mapWalk, relabel, trace, foldedLabel, extraLabel] using (congrArg (fun t => lab e ++ t) ih)

    | «macro» => simpa [nextExpand, expand, mapWalk, relabel, trace, foldedLabel, extraLabel, List.append_assoc] using (congrArg (fun t => (left ++ right) ++ t) ih)





theorem serial_expansion_trace (lab : {u v : V} → E u v → List Window) (ts : List (List Window))

    {u v : V} (p : Walk (FoldEdge E a b) u v) (n : Nat) :

    trace (serialLabel lab ts n) (serialExpand p n) =

      trace (foldedLabel lab ts.flatten []) p := by

  induction n with

  | zero => rfl

  | succ n ih =>

    simp only [serialExpand, serialLabel, ordinaryLabel]

    rw [next_trace]

    have h : @foldedLabel (Carrier V n) (Ordinary E a n) (lastSource a n) (liftVertex b n)

          (@ordinaryLabel V E a lab ts n) (piece ts n) (suffix ts (n+1)) =

        @serialLabel V E a b lab ts n := by

      funext u v e

      cases e with

      | exterior e => rfl

      | «macro» => simpa [foldedLabel, serialLabel] using (suffix_split ts n).symm

    rw [h]

    exact ih





theorem serial_contraction_trace (lab : {u v : V} → E u v → List Window) (ts : List (List Window))

    {u v : V} (n : Nat) (p : Walk (SerialEdge E a b n) (liftVertex u n) (liftVertex v n)) :

    trace (foldedLabel lab ts.flatten []) (serialContract n p) = trace (serialLabel lab ts n) p := by

  rw [← serial_expansion_trace lab ts (serialContract n p) n, serial_expand_contract]



-- First arrival is independent from the unbounded raw-walk claim.

def firstGoal {W : Type} {F : W → W → Type} (goal : W) : {u v : W} → Walk F u v → Prop

  | _, _, .nil _ => True

  | u, _, .cons _ p => u ≠ goal ∧ firstGoal goal p



theorem mapped_firstGoal {W : Type} {F G : W → W → Type}

    (f : {u v : W} → F u v → G u v) (goal : W) {u v : W} (p : Walk F u v) :

    firstGoal goal (mapWalk f p) ↔ firstGoal goal p := by

  induction p with

  | nil => rfl

  | cons e p ih => simp [mapWalk, firstGoal, ih]



theorem expansion_firstGoal (goal : V) {u v : V} (p : Walk (FoldEdge E a b) u v) :

    firstGoal (some goal) (expand p) ↔ firstGoal goal p := by

  induction p with

  | nil => simp [expand, firstGoal]

  | cons e p ih => cases e <;> simp [expand, firstGoal, ih]



theorem next_firstGoal (goal : V) {u v : V} (p : Walk (FoldEdge E a b) u v) :

    firstGoal (some goal) (nextExpand p) ↔ firstGoal goal p := by

  rw [nextExpand, mapped_firstGoal, expansion_firstGoal]



theorem serial_firstGoal (goal : V) {u v : V} (p : Walk (FoldEdge E a b) u v) (n : Nat) :

    firstGoal (liftVertex goal n) (serialExpand p n) ↔ firstGoal goal p := by

  induction n with

  | zero => rfl

  | succ n ih =>

    simp only [liftVertex, serialExpand]

    rw [next_firstGoal]

    exact ih



theorem serial_accounting (lab : {u v : V} → E u v → List Window) (ts : List (List Window))

    {u v : V} (n : Nat) (p : Walk (SerialEdge E a b n) (liftVertex u n) (liftVertex v n)) (C : ℚ) (j : Nat) :

    burden (trace (foldedLabel lab ts.flatten []) (serialContract n p)) = burden (trace (serialLabel lab ts n) p) ∧

    duration (trace (foldedLabel lab ts.flatten []) (serialContract n p)) = duration (trace (serialLabel lab ts n) p) ∧

    budget C (trace (foldedLabel lab ts.flatten []) (serialContract n p)) j = budget C (trace (serialLabel lab ts n) p) j := by

  rw [serial_contraction_trace]

  exact ⟨rfl, rfl, rfl⟩




-- Checked interface data separates the algebraic theorem from its declared class.
structure CertifiedInterface (E : V → V → Type) (a b : V) (n : Nat)
    (lab : {u v : V} → E u v → List Window) (ts : List (List Window)) : Prop where
  finiteVertices : Finite V
  simpleEdges : ∀ u v, Subsingleton (E u v)
  distinctPorts : a ≠ b
  noOldShortcut : E a b → False
  internalPositive : 0 < n
  chainLength : ts.length = n + 1
  chainNonempty : ∀ t ∈ ts, t ≠ []
  exteriorNonempty : ∀ {u v} (e : E u v), lab e ≠ []

theorem burden_nonneg (t : List Window) : 0 ≤ burden t := by
  induction t with
  | nil => simp [burden]
  | cons w t ih => simpa [burden] using add_nonneg w.nonneg ih

theorem duration_positive (t : List Window) (h : t ≠ []) : 0 < duration t := by
  cases t with
  | nil => contradiction
  | cons w t =>
    simp only [duration, List.map_cons, List.sum_cons]
    have hw := w.positive
    omega

theorem burden_append (s t : List Window) : burden (s ++ t) = burden s + burden t := by
  simp [burden, List.sum_append]

theorem duration_append (s t : List Window) : duration (s ++ t) = duration s + duration t := by
  simp [duration, List.sum_append]

theorem macro_exact_totals (ts : List (List Window)) :
    burden ts.flatten = (ts.map burden).sum ∧ duration ts.flatten = (ts.map duration).sum := by
  induction ts with
  | nil => simp [burden, duration]
  | cons t ts ih => simpa [List.flatten_cons, burden_append, duration_append] using ih

theorem piece_nonempty (ts : List (List Window)) (n : Nat)
    (hc : ∀ t ∈ ts, t ≠ []) (hn : n < ts.length) : piece ts n ≠ [] := by
  induction n generalizing ts with
  | zero =>
    cases ts with
    | nil => simp at hn
    | cons t ts => exact hc t (by simp)
  | succ n ih =>
    cases ts with
    | nil => simp at hn
    | cons t ts =>
      apply ih ts
      · intro q hq; exact hc q (by simp [hq])
      · simp at hn; exact hn

theorem suffix_nonempty (ts : List (List Window)) (n : Nat)
    (hc : ∀ t ∈ ts, t ≠ []) (hn : n < ts.length) : suffix ts n ≠ [] := by
  rw [suffix_split ts n]
  intro h
  apply piece_nonempty ts n hc hn
  have hh := congrArg List.length h
  have hz : (piece ts n).length = 0 := by
    simp only [List.length_append, List.length_nil] at hh
    omega
  exact List.eq_nil_of_length_eq_zero hz

theorem ordinary_label_nonempty (lab : {u v : V} → E u v → List Window)
    (ts : List (List Window)) (he : ∀ {u v} (e : E u v), lab e ≠ [])
    (hc : ∀ t ∈ ts, t ≠ []) (n : Nat) (hn : n ≤ ts.length)
    {u v : Carrier V n} (e : Ordinary E a n u v) : ordinaryLabel lab ts n e ≠ [] := by
  induction n with
  | zero => exact he e
  | succ n ih =>
    cases e with
    | old e => exact ih (by omega) e
    | initial => exact piece_nonempty ts n hc (by omega)

theorem serial_label_nonempty (lab : {u v : V} → E u v → List Window)
    (ts : List (List Window)) (n : Nat) (h : CertifiedInterface E a b n lab ts)
    {u v : Carrier V n} (e : SerialEdge E a b n u v) : serialLabel lab ts n e ≠ [] := by
  have hlen := h.chainLength
  cases e with
  | exterior e => exact ordinary_label_nonempty lab ts h.exteriorNonempty h.chainNonempty n (by omega) e
  | «macro» => simpa [serialLabel, foldedLabel] using suffix_nonempty ts n h.chainNonempty (by omega)

-- The source endpoint function concerns a complete route to the declared goal.
theorem endpoint_exists_iff (lab : {u v : V} → E u v → List Window) (ts : List (List Window))
    (s g : V) (n H : Nat) (C : ℚ) :
    (∃ p : Walk (SerialEdge E a b n) (liftVertex s n) (liftVertex g n),
      duration (trace (serialLabel lab ts n) p) ≤ H ∧ burden (trace (serialLabel lab ts n) p) < C) ↔
    (∃ q : Walk (FoldEdge E a b) s g,
      duration (trace (foldedLabel lab ts.flatten []) q) ≤ H ∧ burden (trace (foldedLabel lab ts.flatten []) q) < C) := by
  constructor
  · rintro ⟨p, hD, hC⟩
    refine ⟨serialContract n p, ?_, ?_⟩
    · rwa [serial_contraction_trace lab ts n p]
    · rwa [serial_contraction_trace lab ts n p]
  · rintro ⟨q, hD, hC⟩
    refine ⟨serialExpand q n, ?_, ?_⟩
    · rwa [serial_expansion_trace lab ts q n]
    · rwa [serial_expansion_trace lab ts q n]

theorem serial_contraction_firstGoal (goal : V) {u v : V} (n : Nat)
    (p : Walk (SerialEdge E a b n) (liftVertex u n) (liftVertex v n)) :
    firstGoal goal (serialContract n p) ↔ firstGoal (liftVertex goal n) p := by
  have h := serial_firstGoal goal (serialContract n p) n
  rw [serial_expand_contract] at h
  exact h.symm

theorem executable_routes_iff (lab : {u v : V} → E u v → List Window) (ts : List (List Window))
    (s g : V) (n H : Nat) (C : ℚ) :
    (∃ p : Walk (SerialEdge E a b n) (liftVertex s n) (liftVertex g n),
      firstGoal (liftVertex g n) p ∧ duration (trace (serialLabel lab ts n) p) ≤ H ∧
      burden (trace (serialLabel lab ts n) p) < C) ↔
    (∃ q : Walk (FoldEdge E a b) s g,
      firstGoal g q ∧ duration (trace (foldedLabel lab ts.flatten []) q) ≤ H ∧
      burden (trace (foldedLabel lab ts.flatten []) q) < C) := by
  constructor
  · rintro ⟨p, hF, hD, hC⟩
    refine ⟨serialContract n p, (serial_contraction_firstGoal g n p).2 hF, ?_, ?_⟩
    · rwa [serial_contraction_trace lab ts n p]
    · rwa [serial_contraction_trace lab ts n p]
  · rintro ⟨q, hF, hD, hC⟩
    refine ⟨serialExpand q n, (serial_firstGoal g q n).2 hF, ?_, ?_⟩
    · rwa [serial_expansion_trace lab ts q n]
    · rwa [serial_expansion_trace lab ts q n]

theorem lift_vertex_eq_iff (u v : V) (n : Nat) : liftVertex u n = liftVertex v n ↔ u = v := by
  induction n with
  | zero => rfl
  | succ n ih => simpa [liftVertex] using ih

theorem executable_class_iff (lab : {u v : V} → E u v → List Window) (ts : List (List Window))
    (s g : V) (n H : Nat) (C : ℚ) :
    (liftVertex s n ≠ liftVertex g n ∧ 0 < C ∧ 0 < H ∧
      ∃ p : Walk (SerialEdge E a b n) (liftVertex s n) (liftVertex g n),
        firstGoal (liftVertex g n) p ∧ duration (trace (serialLabel lab ts n) p) ≤ H ∧
        burden (trace (serialLabel lab ts n) p) < C) ↔
    (s ≠ g ∧ 0 < C ∧ 0 < H ∧ ∃ q : Walk (FoldEdge E a b) s g,
      firstGoal g q ∧ duration (trace (foldedLabel lab ts.flatten []) q) ≤ H ∧
      burden (trace (foldedLabel lab ts.flatten []) q) < C) := by
  have ports : (liftVertex s n ≠ liftVertex g n) ↔ s ≠ g := by
    constructor
    · intro h heq; apply h; subst g; rfl
    · intro h heq; exact h ((lift_vertex_eq_iff s g n).1 heq)
  exact and_congr ports (and_congr Iff.rfl (and_congr Iff.rfl (executable_routes_iff lab ts s g n H C)))

theorem serial_function_preserved (lab : {u v : V} → E u v → List Window) (ts : List (List Window))
    {u v : V} (n : Nat) (p : Walk (SerialEdge E a b n) (liftVertex u n) (liftVertex v n))
    {A : Type} (f : List Window → A) :
    f (trace (foldedLabel lab ts.flatten []) (serialContract n p)) = f (trace (serialLabel lab ts n) p) :=
  congrArg f (serial_contraction_trace lab ts n p)

-- A real ordered-trace countermodel: totals agree, the first prefix does not.
def oneThird : Window := ⟨1/3, 1, by norm_num, by decide⟩
def twoThirds : Window := ⟨2/3, 1, by norm_num, by decide⟩
def traceA : List Window := [oneThird, twoThirds]
def traceB : List Window := [twoThirds, oneThird]

theorem ordering_countermodel :
    burden traceA = burden traceB ∧ duration traceA = duration traceB ∧
    burden traceA = 1 ∧ duration traceA = 2 ∧
    budget (1/2) traceA 1 = 1/6 ∧ budget (1/2) traceB 1 = -(1/6) ∧
    budget (1/2) traceA 2 = budget (1/2) traceB 2 := by
  norm_num [traceA, traceB, oneThird, twoThirds, burden, duration, budget]

inductive LeakVertex where
  | start | interior | exit | goal
  deriving DecidableEq

def leakAdj (u v : LeakVertex) : Prop :=
  (u = .start ∧ v = .interior) ∨ (u = .interior ∧ v = .exit) ∨ (u = .interior ∧ v = .goal)
def removedAdj (u v : LeakVertex) : Prop := u = .start ∧ v = .exit

theorem leak_original_route : Nonempty (Walk (fun u v => PLift (leakAdj u v)) .start .goal) := by
  exact ⟨Walk.cons (v := LeakVertex.interior) ⟨by simp [leakAdj]⟩ (Walk.cons (v := LeakVertex.goal) ⟨by simp [leakAdj]⟩ (Walk.nil LeakVertex.goal))⟩

theorem removed_endpoint {u v : LeakVertex} (p : Walk (fun x y => PLift (removedAdj x y)) u v) :
    u = .start ∨ u = .exit → v = .start ∨ v = .exit := by
  induction p with
  | nil => exact id
  | cons e p ih => intro _; exact ih (Or.inr e.down.2)

theorem isolation_countermodel :
    Nonempty (Walk (fun u v => PLift (leakAdj u v)) .start .goal) ∧
    ¬ Nonempty (Walk (fun u v => PLift (removedAdj u v)) .start .goal) ∧
    ¬ leakAdj .start .exit := by
  refine ⟨leak_original_route, ?_, ?_⟩
  · rintro ⟨p⟩
    have h := removed_endpoint p (Or.inl rfl)
    cases h <;> contradiction
  · simp [leakAdj]

-- Vertex transport for a source-graph normalisation. This does not postulate an inverse.
def transportWalk {W : Type} {F : W → W → Type}
    (vertex : V → W) (edge : {u v : V} → E u v → F (vertex u) (vertex v)) :
    {u v : V} → Walk E u v → Walk F (vertex u) (vertex v)
  | _, _, .nil u => .nil (vertex u)
  | _, _, .cons e p => .cons (edge e) (transportWalk vertex edge p)

theorem suffix_empty_after (ts : List (List Window)) (n : Nat) (h : ts.length ≤ n) : suffix ts n = [] := by
  induction n generalizing ts with
  | zero => have hz : ts = [] := List.eq_nil_of_length_eq_zero (by omega); subst ts; rfl
  | succ n ih =>
    cases ts with
    | nil => change suffix [] n = []; exact ih [] (Nat.zero_le n)
    | cons q ts => exact ih ts (by simp at h; omega)

theorem final_source_macro_label (ts : List (List Window)) (n : Nat) (h : ts.length = n + 1) :
    suffix ts n = piece ts n := by
  rw [suffix_split ts n, suffix_empty_after ts (n+1) (by omega), List.append_nil]

theorem transport_trace {W : Type} {F : W → W → Type}
    (vertex : V → W) (edge : {u v : V} → E u v → F (vertex u) (vertex v))
    (sourceLabel : {u v : V} → E u v → List Window) (targetLabel : {u v : W} → F u v → List Window)
    (labelCheck : ∀ {u v} (e : E u v), targetLabel (edge e) = sourceLabel e)
    {u v : V} (p : Walk E u v) :
    trace targetLabel (transportWalk vertex edge p) = trace sourceLabel p := by
  induction p with
  | nil => rfl
  | cons e p ih => simp [transportWalk, trace, labelCheck, ih]

-- The numerical fields are supplied independently and checked against their words.
structure DeclaredAggregates (lab : {u v : V} → E u v → List Window) where
  cost : {u v : V} → E u v → ℚ
  span : {u v : V} → E u v → Nat
  costChecked : ∀ {u v} (e : E u v), cost e = burden (lab e)
  spanChecked : ∀ {u v} (e : E u v), span e = duration (lab e)

def declaredCost (cost : {u v : V} → E u v → ℚ) : {u v : V} → Walk E u v → ℚ
  | _, _, .nil _ => 0
  | _, _, .cons e p => cost e + declaredCost cost p

def declaredSpan (span : {u v : V} → E u v → Nat) : {u v : V} → Walk E u v → Nat
  | _, _, .nil _ => 0
  | _, _, .cons e p => span e + declaredSpan span p

theorem declared_route_accounting (lab : {u v : V} → E u v → List Window)
    (h : DeclaredAggregates lab) {u v : V} (p : Walk E u v) :
    declaredCost (E := E) h.cost p = burden (trace lab p) ∧
    declaredSpan (E := E) (fun {u v} e => h.span (u := u) (v := v) e) p = duration (trace lab p) := by
  induction p with
  | nil => simp [declaredCost, declaredSpan, trace, burden, duration]
  | cons e p ih =>
    constructor
    · simp only [declaredCost, trace, burden_append, h.costChecked, ih.1]
    · simp only [declaredSpan, trace, duration_append]
      rw [ih.2, h.spanChecked e]

theorem declared_macro_accounting (lab : {u v : V} → E u v → List Window)
    (h : DeclaredAggregates lab) {u v : V} (p : Walk E u v)
    (macroCost : ℚ) (macroSpan : Nat)
    (costCheck : macroCost = declaredCost (E := E) h.cost p)
    (spanCheck : macroSpan = declaredSpan (E := E) (fun {u v} e => h.span (u := u) (v := v) e) p) :
    macroCost = burden (trace lab p) ∧ macroSpan = duration (trace lab p) := by
  exact ⟨costCheck.trans (declared_route_accounting lab h p).1,
    spanCheck.trans (declared_route_accounting lab h p).2⟩
end ClaimA












namespace ClaimANormalForm
open ClaimA

variable {V I : Type}

def Exterior (internal : I → V) (x : V) : Prop := ∀ i, x ≠ internal i

def decode (internal : I → V) : Sum {x : V // Exterior internal x} I → V
  | .inl x => x.val
  | .inr i => internal i

theorem decode_injective (internal : I → V) (hinj : Function.Injective internal) :
    Function.Injective (decode internal) := by
  intro x y h
  cases x with
  | inl x =>
    cases y with
    | inl y => exact congrArg Sum.inl (Subtype.ext h)
    | inr j => exact False.elim (x.property j h)
  | inr i =>
    cases y with
    | inl y => exact False.elim (y.property i h.symm)
    | inr j => exact congrArg Sum.inr (hinj h)

theorem decode_surjective (internal : I → V) : Function.Surjective (decode internal) := by
  classical
  intro x
  by_cases h : ∃ i, x = internal i
  · obtain ⟨i, hi⟩ := h
    exact ⟨Sum.inr i, hi.symm⟩
  · refine ⟨Sum.inl ⟨x, ?_⟩, rfl⟩
    intro i hi
    exact h ⟨i, hi⟩

noncomputable def vertexEquiv (internal : I → V) (hinj : Function.Injective internal) :
    Sum {x : V // Exterior internal x} I ≃ V :=
  Equiv.ofBijective (decode internal) ⟨decode_injective internal hinj, decode_surjective internal⟩

structure Isolated (G : V → V → Prop) (internal pred succ : I → V) : Prop where
  incoming : ∀ i x, G x (internal i) → x = pred i
  outgoing : ∀ i y, G (internal i) y → y = succ i
  enters : ∀ i, G (pred i) (internal i)
  leaves : ∀ i, G (internal i) (succ i)

def ChainEdge (internal pred succ : I → V) (x y : V) : Prop :=
  (∃ i, x = pred i ∧ y = internal i) ∨
  (∃ i, x = internal i ∧ y = succ i)

-- Isolation is input; the global edge partition is a conclusion.
theorem edge_partition (G : V → V → Prop) (internal pred succ : I → V)
    (h : Isolated G internal pred succ) (x y : V) :
    G x y ↔
      (Exterior internal x ∧ Exterior internal y ∧ G x y) ∨
      ChainEdge internal pred succ x y := by
  classical
  constructor
  · intro hxy
    by_cases hx : Exterior internal x
    · by_cases hy : Exterior internal y
      · exact Or.inl ⟨hx, hy, hxy⟩
      · obtain ⟨i, hi⟩ : ∃ i, y = internal i := by
          simpa [Exterior] using hy
        exact Or.inr (Or.inl ⟨i, h.incoming i x (hi ▸ hxy), hi⟩)
    · obtain ⟨i, hi⟩ : ∃ i, x = internal i := by
        simpa [Exterior] using hx
      exact Or.inr (Or.inr ⟨i, hi, h.outgoing i y (hi ▸ hxy)⟩)
  · intro hp
    rcases hp with ⟨_, _, hg⟩ | hc
    · exact hg
    · rcases hc with ⟨i, rfl, rfl⟩ | ⟨i, rfl, rfl⟩
      · exact h.enters i
      · exact h.leaves i

-- Canonical adjacency is constructed from exterior edges and forced chain edges.
def NormalAdj (G : V → V → Prop) (internal pred succ : I → V)
    (p q : Sum {x : V // Exterior internal x} I) : Prop :=
  (Exterior internal (decode internal p) ∧ Exterior internal (decode internal q) ∧
    G (decode internal p) (decode internal q)) ∨
  ChainEdge internal pred succ (decode internal p) (decode internal q)

theorem adjacency_transport (G : V → V → Prop) (internal pred succ : I → V)
    (h : Isolated G internal pred succ)
    (p q : Sum {x : V // Exterior internal x} I) :
    G (decode internal p) (decode internal q) ↔ NormalAdj G internal pred succ p q :=
  edge_partition G internal pred succ h _ _

#print axioms decode_injective
#print axioms decode_surjective
#print axioms vertexEquiv
#print axioms edge_partition
#print axioms adjacency_transport


-- A simple graph edge is one proof, not a multiedge token.
noncomputable def simpleEdgeEquiv (G : V → V → Prop) (internal pred succ : I → V)
    (h : Isolated G internal pred succ)
    (p q : Sum {x : V // Exterior internal x} I) :
    PLift (G (decode internal p) (decode internal q)) ≃ PLift (NormalAdj G internal pred succ p q) where
  toFun e := ⟨(adjacency_transport G internal pred succ h p q).mp e.down⟩
  invFun e := ⟨(adjacency_transport G internal pred succ h p q).mpr e.down⟩
  left_inv e := by cases e; rfl
  right_inv e := by cases e; rfl

variable {O : Type}

def carrierToSum : (n : Nat) → Carrier O n → Sum O (Fin n)
  | 0, x => .inl x
  | n+1, none => .inr (Fin.last n)
  | n+1, some x =>
    match carrierToSum n x with
    | .inl o => .inl o
    | .inr i => .inr i.castSucc

def sumToCarrier : (n : Nat) → Sum O (Fin n) → Carrier O n
  | 0, .inl o => o
  | 0, .inr i => Fin.elim0 i
  | n+1, .inl o => some (sumToCarrier n (.inl o))
  | n+1, .inr i => Fin.lastCases none (fun j => some (sumToCarrier n (.inr j))) i

theorem sum_carrier_inverse (n : Nat) (x : Sum O (Fin n)) :
    carrierToSum n (sumToCarrier n x) = x := by
  induction n with
  | zero => cases x with
    | inl o => rfl
    | inr i => exact Fin.elim0 i
  | succ n ih =>
    cases x with
    | inl o => simp [Fin.lastCases_last, Fin.lastCases_castSucc, sumToCarrier, carrierToSum, ih]
    | inr i =>
      induction i using Fin.lastCases with
      | last => simp [Fin.lastCases_last, Fin.lastCases_castSucc, sumToCarrier, carrierToSum]
      | cast j => simp [Fin.lastCases_last, Fin.lastCases_castSucc, sumToCarrier, carrierToSum, ih]

theorem carrier_sum_inverse (n : Nat) (x : Carrier O n) :
    sumToCarrier n (carrierToSum n x) = x := by
  induction n with
  | zero => rfl
  | succ n ih =>
    cases x with
    | none => simp [Fin.lastCases_last, Fin.lastCases_castSucc, carrierToSum, sumToCarrier]
    | some x =>
      have hx := ih x
      cases hs : carrierToSum n x with
      | inl o =>
        rw [hs] at hx
        simp only [carrierToSum, hs, sumToCarrier]
        exact congrArg some hx
      | inr i =>
        rw [hs] at hx
        simp only [carrierToSum, hs, sumToCarrier, Fin.lastCases_castSucc]
        exact congrArg some hx

def orderedCarrierEquiv (n : Nat) : Carrier O n ≃ Sum O (Fin n) where
  toFun := carrierToSum n
  invFun := sumToCarrier n
  left_inv := carrier_sum_inverse n
  right_inv := sum_carrier_inverse n

noncomputable def sourceCarrierEquiv (internal : Fin n → V) (hinj : Function.Injective internal) :
    Carrier {x : V // Exterior internal x} n ≃ V :=
  (orderedCarrierEquiv n).trans (vertexEquiv internal hinj)

#print axioms simpleEdgeEquiv
#print axioms sum_carrier_inverse
#print axioms carrier_sum_inverse
#print axioms orderedCarrierEquiv
#print axioms sourceCarrierEquiv


@[reducible] def pos : (n : Nat) → Fin n → Carrier O n
  | 0, i => Fin.elim0 i
  | n+1, i => Fin.lastCases none (fun j => some (pos n j)) i

@[reducible] def before (a : O) : (n : Nat) → Fin n → Carrier O n
  | 0, i => Fin.elim0 i
  | n+1, i => Fin.lastCases (some (lastSource a n)) (fun j => some (before a n j)) i

variable {E : O → O → Type} {a b : O}

def ordinaryLift {u v : O} (e : E u v) :
    (n : Nat) → Ordinary E a n (liftVertex u n) (liftVertex v n)
  | 0 => e
  | n+1 => .old (ordinaryLift e n)

def ordinaryEnter : (n : Nat) → (i : Fin n) → Ordinary E a n (before a n i) (pos n i)
  | 0, i => Fin.elim0 i
  | n+1, i => by
    induction i using Fin.lastCases with
    | last => simpa [before, pos, Fin.lastCases_last] using
        (Extra.initial : Ordinary E a (n+1) (some (lastSource a n)) none)
    | cast j => simpa [before, pos, Fin.lastCases_castSucc] using
        (Extra.old (ordinaryEnter n j))

-- All actual typed ordinary edges are classified; classification is not input.
theorem ordinary_classification (n : Nat) (x y : Carrier O n) :
    Nonempty (Ordinary E a n x y) ↔
    (∃ u v : O, x = liftVertex u n ∧ y = liftVertex v n ∧ Nonempty (E u v)) ∨
    (∃ i : Fin n, x = before a n i ∧ y = pos n i) := by
  constructor
  · intro he
    induction n with
    | zero => exact Or.inl ⟨x, y, rfl, rfl, he⟩
    | succ n ih =>
      obtain ⟨e⟩ := he
      cases e with
      | old e =>
        rcases (ih _ _ ⟨e⟩) with ⟨u, v, rfl, rfl, he⟩ | ⟨i, rfl, rfl⟩
        · exact Or.inl ⟨u, v, rfl, rfl, he⟩
        · exact Or.inr ⟨i.castSucc, by simp [Fin.lastCases_last, Fin.lastCases_castSucc, before], by simp [Fin.lastCases_last, Fin.lastCases_castSucc, pos]⟩
      | initial => exact Or.inr ⟨Fin.last n, by simp [Fin.lastCases_last, Fin.lastCases_castSucc, before], by simp [Fin.lastCases_last, Fin.lastCases_castSucc, pos]⟩
  · intro hc
    rcases hc with ⟨u, v, rfl, rfl, ⟨e⟩⟩ | ⟨i, rfl, rfl⟩
    · exact ⟨ordinaryLift e n⟩
    · exact ⟨ordinaryEnter n i⟩

theorem serial_classification (n : Nat) (x y : Carrier O n) :
    Nonempty (SerialEdge E a b n x y) ↔
    ((∃ u v : O, x = liftVertex u n ∧ y = liftVertex v n ∧ Nonempty (E u v)) ∨
      (∃ i : Fin n, x = before a n i ∧ y = pos n i)) ∨
    (x = lastSource a n ∧ y = liftVertex b n) := by
  constructor
  · intro ⟨e⟩
    cases e with
    | exterior e => exact Or.inl ((ordinary_classification n _ _).mp ⟨e⟩)
    | «macro» => exact Or.inr ⟨rfl, rfl⟩
  · intro hc
    rcases hc with hc | ⟨rfl, rfl⟩
    · obtain ⟨e⟩ := (ordinary_classification n _ _).mpr hc
      exact ⟨.exterior e⟩
    · exact ⟨.macro⟩

#print axioms ordinary_classification
#print axioms serial_classification


-- Positions retain the input chain's forward order.
theorem carrierToSum_pos (n : Nat) (i : Fin n) :
    carrierToSum n (pos n i : Carrier O n) = Sum.inr i := by
  induction n with
  | zero => exact Fin.elim0 i
  | succ n ih =>
    induction i using Fin.lastCases with
    | last => simp [Fin.lastCases_last, Fin.lastCases_castSucc, pos, carrierToSum]
    | cast i => simp [Fin.lastCases_last, Fin.lastCases_castSucc, pos, carrierToSum, ih]

def predIndex {n : Nat} (i : Fin n) (h : i.val ≠ 0) : Fin n := ⟨i.val - 1, by omega⟩

theorem carrierToSum_before (a : O) (n : Nat) (i : Fin n) :
    carrierToSum n (before a n i) =
      if h : i.val = 0 then Sum.inl a else Sum.inr (predIndex i h) := by
  induction n with
  | zero => exact Fin.elim0 i
  | succ n ih =>
    induction i using Fin.lastCases with
    | last =>
      rw [before, Fin.lastCases_last]
      cases n with
      | zero => rfl
      | succ m =>
        simp only [lastSource, carrierToSum, Fin.val_last, Nat.add_eq_zero_iff,
          Nat.one_ne_zero, and_false, dif_neg, not_false_eq_true]
        apply congrArg Sum.inr
        apply Fin.ext
        simp [predIndex, Fin.last]
    | cast i =>
      rw [before, Fin.lastCases_castSucc]
      simp only [carrierToSum]
      rw [ih]
      simp only [Fin.val_castSucc]
      by_cases h : i.val = 0
      · simp only [dif_pos h]
      · simp only [dif_neg h]
        apply congrArg Sum.inr
        apply Fin.ext
        rfl

#print axioms carrierToSum_pos
#print axioms carrierToSum_before

end ClaimANormalForm
namespace ClaimANormalForm
open ClaimA

variable {V O : Type}

def extraSubsingleton {F : O → O → Type} {a : O}
    (h : ∀ x y, Subsingleton (F x y)) (x y : Option O) : Subsingleton (Extra F a x y) := by
  refine ⟨?_⟩
  intro e f
  cases e <;> cases f
  · exact congrArg Extra.old ((h _ _).elim _ _)
  · rfl

def ordinarySubsingleton {E : O → O → Type} {a : O}
    (h : ∀ x y, Subsingleton (E x y)) :
    (n : Nat) → (x y : Carrier O n) → Subsingleton (Ordinary E a n x y)
  | 0, x, y => h x y
  | n+1, x, y => extraSubsingleton (ordinarySubsingleton h n) x y

def foldSubsingleton {F : O → O → Type} {a b : O}
    (h : ∀ x y, Subsingleton (F x y)) (hab : IsEmpty (F a b))
    (x y : O) : Subsingleton (FoldEdge F a b x y) := by
  refine ⟨?_⟩
  intro e f
  cases e with
  | exterior e =>
    cases f with
    | exterior f => exact congrArg FoldEdge.exterior ((h _ _).elim e f)
    | «macro» => exact (hab.false e).elim
  | «macro» =>
    cases f with
    | exterior f => exact (hab.false f).elim
    | «macro» => rfl

def ordinaryNoFinal {E : O → O → Type} {a : O} (n : Nat) (y : Carrier O (n+1)) :
    IsEmpty (Ordinary E a (n+1) none y) := ⟨fun e => by cases e⟩

def serialSubsingleton {E : O → O → Type} {a b : O}
    (h : ∀ x y, Subsingleton (E x y)) (hab : IsEmpty (E a b)) :
    (n : Nat) → (x y : Carrier O n) → Subsingleton (SerialEdge E a b n x y)
  | 0, x, y => foldSubsingleton h hab x y
  | n+1, x, y => foldSubsingleton (ordinarySubsingleton h (n+1)) (ordinaryNoFinal n _) x y

theorem carrierToSum_lift (o : O) (n : Nat) : carrierToSum n (liftVertex o n) = Sum.inl o := by
  induction n with
  | zero => rfl
  | succ n ih => simp [liftVertex, carrierToSum, ih]

def chainInternal {n : Nat} (v : Fin (n+2) → V) (i : Fin n) : V :=
  v ⟨i.val+1, by omega⟩

theorem chainInternal_injective {n : Nat} (v : Fin (n+2) → V) (hv : Function.Injective v) :
    Function.Injective (chainInternal v) := by
  intro i j hij
  have hh := hv hij
  apply Fin.ext
  have hhval := congrArg Fin.val hh
  dsimp [chainInternal] at hhval
  omega

@[reducible] def ChainOutside {n : Nat} (v : Fin (n+2) → V) := {x : V // Exterior (chainInternal v) x}

def chainStart {n : Nat} (v : Fin (n+2) → V) (hv : Function.Injective v) : ChainOutside v :=
  ⟨v ⟨0, by omega⟩, by
    intro i hi
    have hh := congrArg Fin.val (hv hi)
    dsimp [chainInternal] at hh
    omega⟩

def chainGoal {n : Nat} (v : Fin (n+2) → V) (hv : Function.Injective v) : ChainOutside v :=
  ⟨v ⟨n+1, by omega⟩, by
    intro i hi
    have hh := congrArg Fin.val (hv hi)
    dsimp [chainInternal] at hh
    have hiBound := i.isLt
    omega⟩

def sourceDecode {n : Nat} (v : Fin (n+2) → V) (x : Carrier (ChainOutside v) n) : V :=
  decode (chainInternal v) (carrierToSum n x)

theorem sourceDecode_lift {n : Nat} (v : Fin (n+2) → V) (x : ChainOutside v) :
    sourceDecode v (liftVertex x n) = x.val := by
  simp [sourceDecode, carrierToSum_lift, decode]

theorem sourceDecode_pos {n : Nat} (v : Fin (n+2) → V) (i : Fin n) :
    sourceDecode v (pos n i) = v ⟨i.val+1, by omega⟩ := by
  simp [sourceDecode, carrierToSum_pos, decode, chainInternal]

theorem sourceDecode_before {n : Nat} (v : Fin (n+2) → V)
    (hv : Function.Injective v) (i : Fin n) :
    sourceDecode v (before (chainStart v hv) n i) = v ⟨i.val, by omega⟩ := by
  unfold sourceDecode
  rw [carrierToSum_before]
  split_ifs with hi
  · change v ⟨0, by omega⟩ = v ⟨i.val, by omega⟩
    congr 1
    apply Fin.ext
    exact hi.symm
  · change v ⟨i.val-1+1, by omega⟩ = v ⟨i.val, by omega⟩
    congr 1
    apply Fin.ext
    dsimp
    omega

noncomputable def chainCarrierEquiv {n : Nat} (v : Fin (n+2) → V)
    (hv : Function.Injective v) : Carrier (ChainOutside v) n ≃ V :=
  sourceCarrierEquiv (chainInternal v) (chainInternal_injective v hv)

theorem sourceDecode_injective {n : Nat} (v : Fin (n+2) → V) (hv : Function.Injective v) :
    Function.Injective (sourceDecode v) :=
  (chainCarrierEquiv v hv).injective

#print axioms serialSubsingleton
#print axioms chainInternal_injective
#print axioms sourceDecode_lift
#print axioms sourceDecode_pos
#print axioms sourceDecode_before
#print axioms sourceDecode_injective

end ClaimANormalForm

namespace ClaimANormalForm
open ClaimA

variable {V : Type} {n : Nat}

structure SourceChain (G : V → V → Prop) (v : Fin (n+2) → V) : Prop where
  injective : Function.Injective v
  positive : 0 < n
  edges : ∀ i : Fin (n+1), G (v i.castSucc) (v i.succ)
  incoming : ∀ i : Fin n, ∀ x, G x (chainInternal v i) → x = v ⟨i.val, by omega⟩
  outgoing : ∀ i : Fin n, ∀ y, G (chainInternal v i) y → y = v ⟨i.val+2, by omega⟩
  noShortcut : ¬ G (v ⟨0, by omega⟩) (v ⟨n+1, by omega⟩)

@[reducible] def ExteriorEdge (G : V → V → Prop) (v : Fin (n+2) → V) : ChainOutside v → ChainOutside v → Type :=
  fun x y => PLift (G x.val y.val)

theorem sourceDecode_last (v : Fin (n+2) → V) (hv : Function.Injective v) :
    sourceDecode v (lastSource (chainStart v hv) n) = v ⟨n, by omega⟩ := by
  cases n with
  | zero => rfl
  | succ m => rfl

theorem source_serial_adjacency (G : V → V → Prop) (v : Fin (n+2) → V) (c : SourceChain G v)
    (x y : Carrier (ChainOutside v) n) :
    Nonempty (SerialEdge (ExteriorEdge G v) (chainStart v c.injective) (chainGoal v c.injective) n x y) ↔
    G (sourceDecode v x) (sourceDecode v y) := by
  classical
  rw [serial_classification]
  constructor
  · intro hc
    rcases hc with (⟨u, w, rfl, rfl, ⟨e⟩⟩ | ⟨i, rfl, rfl⟩) | ⟨rfl, rfl⟩
    · simpa [sourceDecode_lift] using e.down
    · rw [sourceDecode_before v c.injective, sourceDecode_pos]
      exact c.edges ⟨i.val, by omega⟩
    · rw [sourceDecode_last, sourceDecode_lift]
      exact c.edges (Fin.last n)
  · intro hg
    let dx := sourceDecode v x
    let dy := sourceDecode v y
    by_cases hy : Exterior (chainInternal v) dy
    · by_cases hx : Exterior (chainInternal v) dx
      · let u : ChainOutside v := ⟨dx, hx⟩
        let w : ChainOutside v := ⟨dy, hy⟩
        have hxu : x = liftVertex u n := by
          apply sourceDecode_injective v c.injective
          exact (sourceDecode_lift v u).symm
        have hyw : y = liftVertex w n := by
          apply sourceDecode_injective v c.injective
          exact (sourceDecode_lift v w).symm
        exact Or.inl (Or.inl ⟨u, w, hxu, hyw, ⟨⟨hg⟩⟩⟩)
      · obtain ⟨i, hi⟩ : ∃ i : Fin n, dx = chainInternal v i := by simpa [Exterior] using hx
        have hout : dy = v ⟨i.val+2, by omega⟩ := by
          apply c.outgoing i
          simpa [dx, dy, hi] using hg
        have hlast : i.val+1 = n := by
          by_contra hn
          have hb : i.val+1 < n := by have hb := i.isLt; omega
          let j : Fin n := ⟨i.val+1, hb⟩
          apply hy j
          change dy = v ⟨i.val+1+1, by omega⟩
          have he : (⟨i.val+2, by omega⟩ : Fin (n+2)) = ⟨i.val+1+1, by omega⟩ := by
            rfl
          exact hout.trans (congrArg v he)
        apply Or.inr
        constructor
        · apply sourceDecode_injective v c.injective
          rw [sourceDecode_last]
          change dx = v ⟨n, by omega⟩
          rw [hi]
          unfold chainInternal
          congr 1
          apply Fin.ext
          exact hlast
        · apply sourceDecode_injective v c.injective
          rw [sourceDecode_lift]
          change dy = v ⟨n+1, by omega⟩
          rw [hout]
          congr 1
          apply Fin.ext
          dsimp
          omega
    · obtain ⟨i, hi⟩ : ∃ i : Fin n, dy = chainInternal v i := by simpa [Exterior] using hy
      have hin : dx = v ⟨i.val, by omega⟩ := by
        apply c.incoming i
        simpa [dx, dy, hi] using hg
      apply Or.inl
      apply Or.inr
      refine ⟨i, ?_, ?_⟩
      · apply sourceDecode_injective v c.injective
        rw [sourceDecode_before]
        exact hin
      · apply sourceDecode_injective v c.injective
        rw [sourceDecode_pos]
        exact hi

noncomputable def sourceEdgeEquiv (G : V → V → Prop) (v : Fin (n+2) → V) (c : SourceChain G v)
    (x y : Carrier (ChainOutside v) n) :
    SerialEdge (ExteriorEdge G v) (chainStart v c.injective) (chainGoal v c.injective) n x y ≃
    PLift (G (sourceDecode v x) (sourceDecode v y)) where
  toFun e := ⟨(source_serial_adjacency G v c x y).mp ⟨e⟩⟩
  invFun e := Classical.choice ((source_serial_adjacency G v c x y).mpr e.down)
  left_inv e := by
    apply (serialSubsingleton (fun _ _ => inferInstance)
      (⟨fun e => c.noShortcut e.down⟩ : IsEmpty (ExteriorEdge G v (chainStart v c.injective) (chainGoal v c.injective))) n x y).elim
  right_inv e := by cases e; rfl



noncomputable def actualTrace {G : V → V → Prop}
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window) (x y : V) : List ClaimA.Window := by
  classical
  exact if h : G x y then lab ⟨h⟩ else []

theorem actualTrace_edge {G : V → V → Prop}
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window) {x y : V} (e : PLift (G x y)) :
    actualTrace (G := G) lab x y = lab e := by
  simp [actualTrace, e.down]

noncomputable def canonicalSourceLabel {G : V → V → Prop} (v : Fin (n+2) → V) (c : SourceChain G v)
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window)
    {x y : Carrier (ChainOutside v) n}
    (_e : SerialEdge (ExteriorEdge G v) (chainStart v c.injective) (chainGoal v c.injective) n x y) : List ClaimA.Window :=
  actualTrace (G := G) lab (sourceDecode v x) (sourceDecode v y)

theorem canonicalSourceLabel_actual {G : V → V → Prop} (v : Fin (n+2) → V) (c : SourceChain G v)
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window)
    {x y : Carrier (ChainOutside v) n}
    (e : SerialEdge (ExteriorEdge G v) (chainStart v c.injective) (chainGoal v c.injective) n x y) :
    canonicalSourceLabel v c lab e = lab (sourceEdgeEquiv G v c x y e) :=
  actualTrace_edge (G := G) lab (sourceEdgeEquiv G v c x y e)

theorem source_enter_label {G : V → V → Prop} (v : Fin (n+2) → V) (c : SourceChain G v)
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window) (i : Fin n) :
    canonicalSourceLabel v c lab (.exterior (ordinaryEnter n i)) =
      actualTrace (G := G) lab (v ⟨i.val, by omega⟩) (v ⟨i.val+1, by omega⟩) := by
  simp only [canonicalSourceLabel, sourceDecode_before, sourceDecode_pos]

theorem source_final_label {G : V → V → Prop} (v : Fin (n+2) → V) (c : SourceChain G v)
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window) :
    canonicalSourceLabel v c lab .macro = actualTrace (G := G) lab (v ⟨n, by omega⟩) (v ⟨n+1, by omega⟩) := by
  simp only [canonicalSourceLabel, sourceDecode_last, sourceDecode_lift]
  rfl

noncomputable def sourcePieces {G : V → V → Prop} (v : Fin (n+2) → V)
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window) : List (List ClaimA.Window) :=
  List.ofFn (fun i : Fin (n+1) => actualTrace (G := G) lab (v i.castSucc) (v i.succ))

theorem sourcePieces_length {G : V → V → Prop} (v : Fin (n+2) → V)
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window) : (sourcePieces (G := G) v lab).length = n+1 := by
  simp [sourcePieces]

#print axioms source_serial_adjacency
#print axioms sourceEdgeEquiv
#print axioms canonicalSourceLabel_actual
#print axioms source_enter_label
#print axioms source_final_label
#print axioms sourcePieces_length


theorem source_exterior_label {G : V → V → Prop} (v : Fin (n+2) → V) (c : SourceChain G v)
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window) {x y : ChainOutside v} (e : ExteriorEdge G v x y) :
    canonicalSourceLabel v c lab (.exterior (ordinaryLift e n)) = lab e := by
  simp only [canonicalSourceLabel, sourceDecode_lift]
  exact actualTrace_edge (G := G) lab e

theorem sourcePieces_nonempty {G : V → V → Prop} (v : Fin (n+2) → V) (c : SourceChain G v)
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window)
    (hne : {x y : V} → (e : PLift (G x y)) → lab e ≠ []) :
    ∀ t ∈ sourcePieces (G := G) v lab, t ≠ [] := by
  intro t ht
  simp only [sourcePieces, List.mem_ofFn] at ht
  obtain ⟨i, rfl⟩ := ht
  rw [actualTrace_edge (G := G) lab ⟨c.edges i⟩]
  exact hne ⟨c.edges i⟩

#print axioms source_exterior_label
#print axioms sourcePieces_nonempty

end ClaimANormalForm
namespace ClaimANormalForm
open ClaimA

variable {O V : Type}

theorem ordinaryLabel_lift {E : O → O → Type} {a : O}
    (lab : {x y : O} → E x y → List ClaimA.Window) (ts : List (List ClaimA.Window))
    {x y : O} (e : E x y) (n : Nat) : ordinaryLabel (a:=a) lab ts n (ordinaryLift e n) = lab e := by
  induction n with
  | zero => rfl
  | succ n ih => exact ih

theorem ordinaryLabel_endpoint_heq {E : O → O → Type} {a : O}
    (lab : {x y : O} → E x y → List Window) (ts : List (List Window))
    (n : Nat) {x y x' y' : Carrier O n}
    (hx : x = x') (hy : y = y')
    {e : Ordinary E a n x y} {e' : Ordinary E a n x' y'} (he : HEq e e') :
    ordinaryLabel lab ts n e = ordinaryLabel lab ts n e' := by
  cases hx
  cases hy
  cases he
  rfl

theorem ordinaryLabel_enter {E : O → O → Type} {a : O}
    (lab : {x y : O} → E x y → List ClaimA.Window) (ts : List (List ClaimA.Window))
    (n : Nat) (i : Fin n) : ordinaryLabel (E := E) (a:=a) lab ts n (ordinaryEnter (E := E) n i) = piece ts i.val := by
  induction n with
  | zero => exact Fin.elim0 i
  | succ n ih =>
    induction i using Fin.lastCases with
    | last =>
      have hx : before a (n+1) (Fin.last n) = some (lastSource a n) := by
        simp [before]
      have hy : pos (O := O) (n+1) (Fin.last n) = none := by
        simp [pos]
      have he : HEq (ordinaryEnter (E := E) (a := a) (n+1) (Fin.last n))
          (Extra.initial : Ordinary E a (n+1) (some (lastSource a n)) none) := by
        simp only [ordinaryEnter, Fin.lastCases_last]
        exact cast_heq _ _
      have h := ordinaryLabel_endpoint_heq lab ts (n+1) hx hy he
      simpa [ordinaryLabel, extraLabel] using h
    | cast i =>
      have hx : before a (n+1) i.castSucc = some (before a n i) := by
        simp [before]
      have hy : pos (O := O) (n+1) i.castSucc = some (pos (O := O) n i) := by
        simp [pos]
      have he : HEq (ordinaryEnter (E := E) (a := a) (n+1) i.castSucc)
          (Extra.old (ordinaryEnter (E := E) (a := a) n i) :
            Ordinary E a (n+1) (some (before a n i)) (some (pos (O := O) n i))) := by
        simp only [ordinaryEnter, Fin.lastCases_castSucc]
        exact cast_heq _ _
      have h := ordinaryLabel_endpoint_heq lab ts (n+1) hx hy he
      have h' : ordinaryLabel lab ts (n+1)
          (Extra.old (ordinaryEnter (E := E) (a := a) n i)) = piece ts i.val := ih i
      exact h.trans h'

theorem piece_ofFn (k : Nat) (f : Fin k → List ClaimA.Window) (i : Fin k) : piece (List.ofFn f) i.val = f i := by
  induction k with
  | zero => exact Fin.elim0 i
  | succ k ih =>
    induction i using Fin.cases with
    | zero => simp [List.ofFn_succ, piece]
    | succ i => simp [List.ofFn_succ, piece, ih]

theorem suffix_last_eq_piece (ts : List (List ClaimA.Window)) (n : Nat) (h : ts.length = n+1) :
    suffix ts n = piece ts n := by
  induction n generalizing ts with
  | zero =>
    cases ts with
    | nil => simp at h
    | cons t ts =>
      have ht : ts = [] := by simpa using h
      subst ts
      simp [suffix, piece]
  | succ n ih =>
    cases ts with
    | nil => simp at h
    | cons t ts =>
      apply ih
      simpa using h

variable {n : Nat}

theorem serial_source_label (G : V → V → Prop) (v : Fin (n+2) → V) (c : SourceChain G v)
    (lab : {x y : V} → PLift (G x y) → List ClaimA.Window)
    {x y : Carrier (ChainOutside v) n}
    (e : SerialEdge (ExteriorEdge G v) (chainStart v c.injective) (chainGoal v c.injective) n x y) :
    serialLabel (fun e => lab e) (sourcePieces (G := G) v lab) n e = canonicalSourceLabel v c lab e := by
  cases e with
  | exterior e =>
    have he := (ordinary_classification n _ _).mp ⟨e⟩
    rcases he with ⟨u, w, rfl, rfl, ⟨e0⟩⟩ | ⟨i, rfl, rfl⟩
    · have hr : e = ordinaryLift e0 n := (ordinarySubsingleton (fun _ _ => inferInstance) n _ _).elim _ _
      subst e
      simp only [ClaimA.serialLabel, ClaimA.foldedLabel, List.append_nil]
      rw [ ordinaryLabel_lift, source_exterior_label]
    · have hr : e = ordinaryEnter n i := (ordinarySubsingleton (fun _ _ => inferInstance) n _ _).elim _ _
      subst e
      simp only [ClaimA.serialLabel, ClaimA.foldedLabel, List.append_nil]
      rw [ ordinaryLabel_enter, source_enter_label]
      unfold sourcePieces
      have hp := piece_ofFn (n+1) (fun j : Fin (n+1) => actualTrace (G := G) lab (v j.castSucc) (v j.succ))
        (⟨i.val, by omega⟩ : Fin (n+1))
      exact hp
  | «macro» =>
    simp only [ClaimA.serialLabel, ClaimA.foldedLabel, List.append_nil]
    rw [ suffix_last_eq_piece _ n (sourcePieces_length (G := G) v lab), source_final_label]
    unfold sourcePieces
    exact piece_ofFn (n+1) _ (Fin.last n)

#print axioms ordinaryLabel_lift
#print axioms ordinaryLabel_enter
#print axioms piece_ofFn
#print axioms suffix_last_eq_piece
#print axioms serial_source_label

end ClaimANormalForm

namespace ClaimA
section TransportEquiv
variable {V W X : Type} {E : V → V → Type} {F : W → W → Type} {K : X → X → Type}

def isoCastFiber (D : V → V → Type) {u v u' v' : V}
    (hu : u = u') (hv : v = v') (e : D u v) : D u' v' := by
  cases hu
  cases hv
  exact e

theorem isoCastFiber_heq (D : V → V → Type) {u v u' v' : V}
    (hu : u = u') (hv : v = v') (e : D u v) :
    HEq (isoCastFiber D hu hv e) e := by
  cases hu
  cases hv
  rfl

def isoCastWalk {u v u' v' : V} (hu : u = u') (hv : v = v')
    (p : Walk E u v) : Walk E u' v' :=
  isoCastFiber (Walk E) hu hv p

theorem isoCastWalk_heq {u v u' v' : V} (hu : u = u') (hv : v = v')
    (p : Walk E u v) : HEq (isoCastWalk hu hv p) p :=
  isoCastFiber_heq (Walk E) hu hv p

def isoForwardEdge (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {u v : V} (e : E u v) : F (vertex u) (vertex v) :=
  edgeEquiv u v e

def isoInverseEdge (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {x y : W} (e : F x y) : E (vertex.symm x) (vertex.symm y) :=
  (edgeEquiv (vertex.symm x) (vertex.symm y)).symm
    (isoCastFiber F (vertex.apply_symm_apply x).symm
      (vertex.apply_symm_apply y).symm e)

theorem isoForward_inverseEdge_heq (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {x y : W} (e : F x y) :
    HEq (isoForwardEdge vertex edgeEquiv (isoInverseEdge vertex edgeEquiv e)) e := by
  have h := (edgeEquiv (vertex.symm x) (vertex.symm y)).apply_symm_apply
    (isoCastFiber F (vertex.apply_symm_apply x).symm
      (vertex.apply_symm_apply y).symm e)
  exact (heq_of_eq h).trans
    (isoCastFiber_heq F (vertex.apply_symm_apply x).symm
      (vertex.apply_symm_apply y).symm e)

theorem isoForwardEdge_reflect_heq (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {u v u' v' : V} (e : E u v) (e' : E u' v')
    (hu : vertex u = vertex u') (hv : vertex v = vertex v')
    (h : HEq (isoForwardEdge vertex edgeEquiv e)
      (isoForwardEdge vertex edgeEquiv e')) : HEq e e' := by
  have hU : u = u' := vertex.injective hu
  have hV : v = v' := vertex.injective hv
  subst u'
  subst v'
  exact heq_of_eq ((edgeEquiv u v).injective (eq_of_heq h))

theorem isoInverse_forwardEdge_heq (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {u v : V} (e : E u v) :
    HEq (isoInverseEdge vertex edgeEquiv (isoForwardEdge vertex edgeEquiv e)) e := by
  apply isoForwardEdge_reflect_heq vertex edgeEquiv
    (isoInverseEdge vertex edgeEquiv (isoForwardEdge vertex edgeEquiv e)) e
  · exact vertex.apply_symm_apply (vertex u)
  · exact vertex.apply_symm_apply (vertex v)
  · exact isoForward_inverseEdge_heq vertex edgeEquiv (isoForwardEdge vertex edgeEquiv e)

theorem isoNil_heq {u u' : V} (hu : u = u') :
    HEq (Walk.nil (E := E) u) (Walk.nil (E := E) u') := by
  cases hu
  rfl

theorem isoCons_heq {u v w u' v' w' : V}
    (hu : u = u') (hv : v = v') (hw : w = w')
    (e : E u v) (e' : E u' v') (p : Walk E v w) (p' : Walk E v' w')
    (he : HEq e e') (hp : HEq p p') :
    HEq (Walk.cons e p) (Walk.cons e' p') := by
  subst u'
  subst v'
  subst w'
  cases he
  cases hp
  rfl

theorem isoTransportWalk_comp
    (f : V → W) (edge₁ : {u v : V} → E u v → F (f u) (f v))
    (g : W → X) (edge₂ : {x y : W} → F x y → K (g x) (g y))
    {u v : V} (p : Walk E u v) :
    transportWalk g edge₂ (transportWalk f edge₁ p) =
      transportWalk (fun x => g (f x)) (fun e => edge₂ (edge₁ e)) p := by
  induction p with
  | nil u => rfl
  | cons e p ih => simp only [transportWalk, ih]

theorem isoTransportWalk_identity_heq
    (vertex : V → V) (edge : {u v : V} → E u v → E (vertex u) (vertex v))
    (vertex_eq : ∀ u, vertex u = u)
    (edge_eq : ∀ {u v : V} (e : E u v), HEq (edge e) e)
    {u v : V} (p : Walk E u v) : HEq (transportWalk vertex edge p) p := by
  induction p with
  | nil u => exact isoNil_heq (vertex_eq u)
  | @cons u v w e p ih =>
    exact isoCons_heq (vertex_eq u) (vertex_eq v) (vertex_eq w)
      (edge e) e (transportWalk vertex edge p) p (edge_eq e) ih

theorem isoTransportWalk_heq
    (vertex : V → W) (edge : {u v : V} → E u v → F (vertex u) (vertex v))
    {u v u' v' : V} (hu : u = u') (hv : v = v')
    (p : Walk E u v) (p' : Walk E u' v') (hp : HEq p p') :
    HEq (transportWalk vertex edge p) (transportWalk vertex edge p') := by
  subst u'
  subst v'
  cases hp
  rfl

theorem isoInverse_forwardWalk_heq (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {u v : V} (p : Walk E u v) :
    HEq (transportWalk vertex.symm (isoInverseEdge vertex edgeEquiv)
      (transportWalk vertex (isoForwardEdge vertex edgeEquiv) p)) p := by
  rw [isoTransportWalk_comp]
  exact isoTransportWalk_identity_heq
    (fun x => vertex.symm (vertex x))
    (fun e => isoInverseEdge vertex edgeEquiv (isoForwardEdge vertex edgeEquiv e))
    vertex.symm_apply_apply
    (fun e => isoInverse_forwardEdge_heq vertex edgeEquiv e) p

theorem isoForward_inverseWalk_heq (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {x y : W} (p : Walk F x y) :
    HEq (transportWalk vertex (isoForwardEdge vertex edgeEquiv)
      (transportWalk vertex.symm (isoInverseEdge vertex edgeEquiv) p)) p := by
  rw [isoTransportWalk_comp]
  exact isoTransportWalk_identity_heq
    (fun x => vertex (vertex.symm x))
    (fun e => isoForwardEdge vertex edgeEquiv (isoInverseEdge vertex edgeEquiv e))
    vertex.apply_symm_apply
    (fun e => isoForward_inverseEdge_heq vertex edgeEquiv e) p

def isoBackwardWalk (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {u v : V} (p : Walk F (vertex u) (vertex v)) : Walk E u v :=
  isoCastWalk (vertex.symm_apply_apply u) (vertex.symm_apply_apply v)
    (transportWalk vertex.symm (isoInverseEdge vertex edgeEquiv) p)

theorem isoBackward_forwardWalk (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {u v : V} (p : Walk E u v) :
    isoBackwardWalk vertex edgeEquiv
      (transportWalk vertex (isoForwardEdge vertex edgeEquiv) p) = p := by
  apply eq_of_heq
  exact (isoCastWalk_heq (vertex.symm_apply_apply u) (vertex.symm_apply_apply v)
    (transportWalk vertex.symm (isoInverseEdge vertex edgeEquiv)
      (transportWalk vertex (isoForwardEdge vertex edgeEquiv) p))).trans
        (isoInverse_forwardWalk_heq vertex edgeEquiv p)

theorem isoForward_backwardWalk (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    {u v : V} (p : Walk F (vertex u) (vertex v)) :
    transportWalk vertex (isoForwardEdge vertex edgeEquiv)
      (isoBackwardWalk vertex edgeEquiv p) = p := by
  apply eq_of_heq
  have hc := isoCastWalk_heq (vertex.symm_apply_apply u) (vertex.symm_apply_apply v)
    (transportWalk vertex.symm (isoInverseEdge vertex edgeEquiv) p)
  have ht := isoTransportWalk_heq vertex (isoForwardEdge vertex edgeEquiv)
    (vertex.symm_apply_apply u).symm (vertex.symm_apply_apply v).symm
    (isoBackwardWalk vertex edgeEquiv p)
    (transportWalk vertex.symm (isoInverseEdge vertex edgeEquiv) p) hc
  exact ht.trans (isoForward_inverseWalk_heq vertex edgeEquiv p)

def transportWalkEquiv (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v)) (u v : V) :
    Walk E u v ≃ Walk F (vertex u) (vertex v) where
  toFun := transportWalk vertex (isoForwardEdge vertex edgeEquiv)
  invFun := isoBackwardWalk vertex edgeEquiv
  left_inv := isoBackward_forwardWalk vertex edgeEquiv
  right_inv := isoForward_backwardWalk vertex edgeEquiv

-- External endpoints x,y may be fixed independently of the source indices u,v.
def transportWalkEndpointEquiv (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    (u v : V) (x y : W) (hx : vertex u = x) (hy : vertex v = y) :
    Walk E u v ≃ Walk F x y := by
  cases hx
  cases hy
  exact transportWalkEquiv vertex edgeEquiv u v

#print axioms isoInverse_forwardEdge_heq
#print axioms isoInverse_forwardWalk_heq
#print axioms isoForward_inverseWalk_heq
#print axioms isoBackward_forwardWalk
#print axioms isoForward_backwardWalk
#print axioms transportWalkEquiv
#print axioms transportWalkEndpointEquiv
end TransportEquiv
end ClaimA


namespace ClaimA
section CastProperties
variable {V W : Type} {E : V → V → Type} {F : W → W → Type}

theorem isoCastWalk_trace
    (lab : {u v : V} → E u v → List Window)
    {u v u' v' : V} (hu : u = u') (hv : v = v') (p : Walk E u v) :
    trace lab (isoCastWalk hu hv p) = trace lab p := by
  cases hu
  cases hv
  rfl

theorem isoCastWalk_firstGoal (goal : V)
    {u v u' v' : V} (hu : u = u') (hv : v = v') (p : Walk E u v) :
    firstGoal goal (isoCastWalk hu hv p) ↔ firstGoal goal p := by
  cases hu
  cases hv
  rfl

theorem isoTransport_firstGoal (vertex : V → W)
    (hinj : Function.Injective vertex)
    (edge : {u v : V} → E u v → F (vertex u) (vertex v))
    (goal : V) {u v : V} (p : Walk E u v) :
    firstGoal (vertex goal) (transportWalk vertex edge p) ↔ firstGoal goal p := by
  induction p with
  | nil u => rfl
  | @cons u v w e p ih =>
    change (vertex u ≠ vertex goal ∧
      firstGoal (vertex goal) (transportWalk vertex edge p)) ↔
      (u ≠ goal ∧ firstGoal goal p)
    constructor
    · rintro ⟨hu, hp⟩
      exact ⟨fun h => hu (congrArg vertex h), ih.mp hp⟩
    · rintro ⟨hu, hp⟩
      exact ⟨fun h => hu (hinj h), ih.mpr hp⟩

#print axioms isoCastWalk_trace
#print axioms isoCastWalk_firstGoal
#print axioms isoTransport_firstGoal
end CastProperties
end ClaimA


namespace ClaimANormalForm
open ClaimA
variable {V : Type} {n : Nat} {G : V → V → Prop} {v : Fin (n + 2) → V}

theorem folded_source_adjacency (c : SourceChain G v) (x y : ChainOutside v) :
    Nonempty (FoldEdge (ExteriorEdge G v) (chainStart v c.injective)
      (chainGoal v c.injective) x y) ↔
      G x.val y.val ∨ (x = chainStart v c.injective ∧ y = chainGoal v c.injective) := by
  constructor
  · rintro ⟨e⟩
    cases e with
    | exterior e => exact Or.inl e.down
    | «macro» => exact Or.inr ⟨rfl, rfl⟩
  · rintro (h | ⟨rfl, rfl⟩)
    · exact ⟨FoldEdge.exterior ⟨h⟩⟩
    · exact ⟨FoldEdge.macro⟩

theorem folded_source_subsingleton (c : SourceChain G v) (x y : ChainOutside v) :
    Subsingleton (FoldEdge (ExteriorEdge G v) (chainStart v c.injective)
      (chainGoal v c.injective) x y) := by
  have hE : ∀ u w, Subsingleton (ExteriorEdge G v u w) := by
    intro u w
    unfold ExteriorEdge
    infer_instance
  have hNo : IsEmpty (ExteriorEdge G v (chainStart v c.injective)
      (chainGoal v c.injective)) := ⟨fun e => c.noShortcut e.down⟩
  exact foldSubsingleton hE hNo x y

#print axioms folded_source_adjacency
#print axioms folded_source_subsingleton
end ClaimANormalForm
namespace ClaimANormalForm
open ClaimA
variable {V : Type} {n : Nat} {G : V → V → Prop} {v : Fin (n+2) → V}
variable (c : SourceChain G v)
variable (lab : {x y : V} → PLift (G x y) → List Window)
variable (h : DeclaredAggregates (E := fun x y => PLift (G x y)) lab)

def sourceCosts : List ℚ := List.ofFn (fun i : Fin (n+1) =>
  h.cost (u := v i.castSucc) (v := v i.succ) ⟨c.edges i⟩)

def sourceSpans : List Nat := List.ofFn (fun i : Fin (n+1) =>
  h.span (u := v i.castSucc) (v := v i.succ) ⟨c.edges i⟩)

theorem sourceCosts_checked : sourceCosts c lab h =
    ((sourcePieces (G := G) v lab).map burden) := by
  unfold sourceCosts sourcePieces
  rw [List.map_ofFn]
  apply congrArg (fun f : Fin (n+1) → ℚ => List.ofFn f)
  funext i
  change h.cost ⟨c.edges i⟩ = burden (actualTrace (G := G) lab (v i.castSucc) (v i.succ))
  rw [actualTrace_edge (G := G) lab ⟨c.edges i⟩]
  exact h.costChecked ⟨c.edges i⟩

theorem sourceSpans_checked : sourceSpans c lab h =
    ((sourcePieces (G := G) v lab).map duration) := by
  unfold sourceSpans sourcePieces
  rw [List.map_ofFn]
  apply congrArg (fun f : Fin (n+1) → Nat => List.ofFn f)
  funext i
  change h.span ⟨c.edges i⟩ = duration (actualTrace (G := G) lab (v i.castSucc) (v i.succ))
  rw [actualTrace_edge (G := G) lab ⟨c.edges i⟩]
  exact h.spanChecked ⟨c.edges i⟩

theorem source_macro_cost_checked : (sourceCosts c lab h).sum =
    burden (sourcePieces (G := G) v lab).flatten := by
  rw [sourceCosts_checked]
  exact (macro_exact_totals (sourcePieces (G := G) v lab)).1.symm

theorem source_macro_span_checked : (sourceSpans c lab h).sum =
    duration (sourcePieces (G := G) v lab).flatten := by
  rw [sourceSpans_checked]
  exact (macro_exact_totals (sourcePieces (G := G) v lab)).2.symm

noncomputable def foldedSourceLabel :
    {x y : ChainOutside v} → FoldEdge (ExteriorEdge G v)
      (chainStart v c.injective) (chainGoal v c.injective) x y → List Window :=
  foldedLabel (E := ExteriorEdge G v)
    (fun {x y} (e : ExteriorEdge G v x y) => lab e)
    (sourcePieces (G := G) v lab).flatten []

noncomputable def foldedSourceAggregates :
    DeclaredAggregates (E := FoldEdge (ExteriorEdge G v)
      (chainStart v c.injective) (chainGoal v c.injective)) (foldedSourceLabel c lab) where
  cost := fun {x y} e => match e with
    | .exterior e => h.cost e
    | .macro => (sourceCosts c lab h).sum
  span := fun {x y} e => match e with
    | .exterior e => h.span e
    | .macro => (sourceSpans c lab h).sum
  costChecked := by
    intro x y e
    cases e with
    | exterior e => exact h.costChecked e
    | «macro» =>
      simpa only [foldedSourceLabel, foldedLabel, List.append_nil]
        using source_macro_cost_checked c lab h
  spanChecked := by
    intro x y e
    cases e with
    | exterior e => exact h.spanChecked e
    | «macro» =>
      simpa only [foldedSourceLabel, foldedLabel, List.append_nil]
        using source_macro_span_checked c lab h

#print axioms sourceCosts_checked
#print axioms sourceSpans_checked
#print axioms source_macro_cost_checked
#print axioms source_macro_span_checked
#print axioms foldedSourceAggregates
end ClaimANormalForm

namespace ClaimA
variable {V W : Type} {E : V → V → Type} {F : W → W → Type}

theorem transportWalkEndpointEquiv_apply
    (vertex : V ≃ W)
    (edgeEquiv : ∀ u v, E u v ≃ F (vertex u) (vertex v))
    (u v : V) (x y : W) (hx : vertex u = x) (hy : vertex v = y)
    (p : Walk E u v) :
    transportWalkEndpointEquiv vertex edgeEquiv u v x y hx hy p =
      isoCastWalk hx hy (transportWalk vertex (isoForwardEdge vertex edgeEquiv) p) := by
  cases hx
  cases hy
  rfl

def serialRouteEquiv (a b : V) (n : Nat) (u v : V) :
    Walk (SerialEdge E a b n) (liftVertex u n) (liftVertex v n) ≃
      Walk (FoldEdge E a b) u v where
  toFun := serialContract n
  invFun := fun p => serialExpand p n
  left_inv := serial_expand_contract n
  right_inv := fun p => serial_contract_expand p n
end ClaimA

namespace ClaimANormalForm
open ClaimA
variable {V : Type} {n : Nat}
variable (G : V → V → Prop) (v : Fin (n+2) → V) (c : SourceChain G v)

noncomputable def sourceRawEquiv (s g : ChainOutside v) :
    Walk (SerialEdge (ExteriorEdge G v) (chainStart v c.injective)
      (chainGoal v c.injective) n) (liftVertex s n) (liftVertex g n) ≃
      Walk (fun x y => PLift (G x y)) s.val g.val :=
  transportWalkEndpointEquiv (chainCarrierEquiv v c.injective)
    (sourceEdgeEquiv G v c) (liftVertex s n) (liftVertex g n) s.val g.val
    (sourceDecode_lift v s) (sourceDecode_lift v g)

noncomputable def sourceFoldEquiv (s g : ChainOutside v) :
    Walk (fun x y => PLift (G x y)) s.val g.val ≃
      Walk (FoldEdge (ExteriorEdge G v) (chainStart v c.injective)
        (chainGoal v c.injective)) s g :=
  (sourceRawEquiv G v c s g).symm.trans
    (serialRouteEquiv (chainStart v c.injective) (chainGoal v c.injective) n s g)

theorem source_fold_expand (s g : ChainOutside v)
    (p : Walk (fun x y => PLift (G x y)) s.val g.val) :
    (sourceFoldEquiv G v c s g).symm (sourceFoldEquiv G v c s g p) = p :=
  (sourceFoldEquiv G v c s g).symm_apply_apply p

theorem source_expand_fold (s g : ChainOutside v)
    (q : Walk (FoldEdge (ExteriorEdge G v) (chainStart v c.injective)
      (chainGoal v c.injective)) s g) :
    sourceFoldEquiv G v c s g ((sourceFoldEquiv G v c s g).symm q) = q :=
  (sourceFoldEquiv G v c s g).apply_symm_apply q

def exteriorLabel
    (lab : {x y : V} → PLift (G x y) → List Window) :
    {x y : ChainOutside v} → ExteriorEdge G v x y → List Window :=
  fun e => lab e

theorem sourceRawEquiv_trace
    (lab : {x y : V} → PLift (G x y) → List Window) (s g : ChainOutside v)
    (p : Walk (SerialEdge (ExteriorEdge G v) (chainStart v c.injective)
      (chainGoal v c.injective) n) (liftVertex s n) (liftVertex g n)) :
    trace lab (sourceRawEquiv G v c s g p) =
      trace (serialLabel (exteriorLabel G v lab) (sourcePieces (G := G) v lab) n) p := by
  erw [sourceRawEquiv, transportWalkEndpointEquiv_apply, isoCastWalk_trace]
  apply transport_trace
  intro x y e
  exact ((serial_source_label G v c lab e).trans
    (canonicalSourceLabel_actual v c lab e)).symm

theorem sourceFoldEquiv_trace
    (lab : {x y : V} → PLift (G x y) → List Window) (s g : ChainOutside v)
    (p : Walk (fun x y => PLift (G x y)) s.val g.val) :
    trace (foldedSourceLabel c lab) (sourceFoldEquiv G v c s g p) = trace lab p := by
  let r := (sourceRawEquiv G v c s g).symm p
  have hr := sourceRawEquiv_trace G v c lab s g r
  dsimp [r] at hr
  rw [(sourceRawEquiv G v c s g).apply_symm_apply] at hr
  exact (serial_contraction_trace (exteriorLabel G v lab)
    (sourcePieces (G := G) v lab) n r).trans hr.symm

theorem source_expansion_trace
    (lab : {x y : V} → PLift (G x y) → List Window) (s g : ChainOutside v)
    (q : Walk (FoldEdge (ExteriorEdge G v) (chainStart v c.injective)
      (chainGoal v c.injective)) s g) :
    trace lab ((sourceFoldEquiv G v c s g).symm q) = trace (foldedSourceLabel c lab) q := by
  have h := sourceFoldEquiv_trace G v c lab s g ((sourceFoldEquiv G v c s g).symm q)
  rw [(sourceFoldEquiv G v c s g).apply_symm_apply] at h
  exact h.symm

theorem source_function_preserved
    (lab : {x y : V} → PLift (G x y) → List Window) (s g : ChainOutside v)
    (p : Walk (fun x y => PLift (G x y)) s.val g.val)
    {A : Type} (f : List Window → A) :
    f (trace (foldedSourceLabel c lab) (sourceFoldEquiv G v c s g p)) =
      f (trace lab p) :=
  congrArg f (sourceFoldEquiv_trace G v c lab s g p)

theorem source_prefix_budgets
    (lab : {x y : V} → PLift (G x y) → List Window) (s g : ChainOutside v)
    (p : Walk (fun x y => PLift (G x y)) s.val g.val) (C : ℚ) (j : Nat) :
    budget C (trace (foldedSourceLabel c lab) (sourceFoldEquiv G v c s g p)) j =
      budget C (trace lab p) j :=
  source_function_preserved G v c lab s g p (fun t => budget C t j)

theorem sourceRawEquiv_firstGoal (s g : ChainOutside v)
    (p : Walk (SerialEdge (ExteriorEdge G v) (chainStart v c.injective)
      (chainGoal v c.injective) n) (liftVertex s n) (liftVertex g n)) :
    firstGoal g.val (sourceRawEquiv G v c s g p) ↔ firstGoal (liftVertex g n) p := by
  erw [sourceRawEquiv, transportWalkEndpointEquiv_apply, isoCastWalk_firstGoal]
  have h := isoTransport_firstGoal (F := fun x y => PLift (G x y))
    (chainCarrierEquiv v c.injective)
    (chainCarrierEquiv v c.injective).injective
    (isoForwardEdge (F := fun x y => PLift (G x y))
      (chainCarrierEquiv v c.injective) (sourceEdgeEquiv G v c))
    (liftVertex g n) p
  change firstGoal (sourceDecode v (liftVertex g n)) _ ↔ _ at h
  erw [sourceDecode_lift] at h
  exact h

theorem sourceFoldEquiv_firstGoal (s g : ChainOutside v)
    (p : Walk (fun x y => PLift (G x y)) s.val g.val) :
    firstGoal g (sourceFoldEquiv G v c s g p) ↔ firstGoal g.val p := by
  let r := (sourceRawEquiv G v c s g).symm p
  have hr := sourceRawEquiv_firstGoal G v c s g r
  dsimp [r] at hr
  rw [(sourceRawEquiv G v c s g).apply_symm_apply] at hr
  exact (serial_contraction_firstGoal g n r).trans hr.symm

theorem source_executable_exists
    (lab : {x y : V} → PLift (G x y) → List Window)
    (s g : ChainOutside v) (H : Nat) (C : ℚ) :
    (∃ p : Walk (fun x y => PLift (G x y)) s.val g.val,
      firstGoal g.val p ∧ duration (trace lab p) ≤ H ∧ burden (trace lab p) < C) ↔
    (∃ q : Walk (FoldEdge (ExteriorEdge G v) (chainStart v c.injective)
        (chainGoal v c.injective)) s g,
      firstGoal g q ∧ duration (trace (foldedSourceLabel c lab) q) ≤ H ∧
        burden (trace (foldedSourceLabel c lab) q) < C) := by
  constructor
  · rintro ⟨p, hp, hd, hc⟩
    refine ⟨sourceFoldEquiv G v c s g p, (sourceFoldEquiv_firstGoal G v c s g p).mpr hp, ?_, ?_⟩
    · rwa [sourceFoldEquiv_trace]
    · rwa [sourceFoldEquiv_trace]
  · rintro ⟨q, hq, hd, hc⟩
    let p := (sourceFoldEquiv G v c s g).symm q
    have hp : firstGoal g.val p := by
      apply (sourceFoldEquiv_firstGoal G v c s g p).mp
      simpa [p] using hq
    refine ⟨p, hp, ?_, ?_⟩
    · rwa [source_expansion_trace]
    · rwa [source_expansion_trace]

theorem source_executable_class
    (lab : {x y : V} → PLift (G x y) → List Window)
    (s g : ChainOutside v) (H : Nat) (C : ℚ) :
    (s.val ≠ g.val ∧ 0 < H ∧ 0 < C ∧
      ∃ p : Walk (fun x y => PLift (G x y)) s.val g.val,
        firstGoal g.val p ∧ duration (trace lab p) ≤ H ∧ burden (trace lab p) < C) ↔
    (s ≠ g ∧ 0 < H ∧ 0 < C ∧
      ∃ q : Walk (FoldEdge (ExteriorEdge G v) (chainStart v c.injective)
          (chainGoal v c.injective)) s g,
        firstGoal g q ∧ duration (trace (foldedSourceLabel c lab) q) ≤ H ∧
          burden (trace (foldedSourceLabel c lab) q) < C) := by
  have he : s.val ≠ g.val ↔ s ≠ g := by
    constructor
    · intro h e; exact h (congrArg Subtype.val e)
    · intro h e; exact h (Subtype.ext e)
  rw [he, source_executable_exists]

theorem source_declared_accounting
    (lab : {x y : V} → PLift (G x y) → List Window)
    (h : DeclaredAggregates (E := fun x y => PLift (G x y)) lab)
    (s g : ChainOutside v) (p : Walk (fun x y => PLift (G x y)) s.val g.val) :
    declaredCost (foldedSourceAggregates c lab h).cost (sourceFoldEquiv G v c s g p) =
      declaredCost h.cost p ∧
    declaredSpan (fun {x y} e => (foldedSourceAggregates c lab h).span (u := x) (v := y) e)
        (sourceFoldEquiv G v c s g p) =
      declaredSpan (fun {x y} e => h.span (u := x) (v := y) e) p := by
  have hf := declared_route_accounting (foldedSourceLabel c lab)
    (foldedSourceAggregates c lab h) (sourceFoldEquiv G v c s g p)
  have hs := declared_route_accounting lab h p
  constructor
  · rw [hf.1, hs.1, sourceFoldEquiv_trace]
  · rw [hf.2, hs.2, sourceFoldEquiv_trace]

theorem source_certified_interface [Finite V]
    (lab : {x y : V} → PLift (G x y) → List Window)
    (hne : {x y : V} → (e : PLift (G x y)) → lab e ≠ []) :
    CertifiedInterface (ExteriorEdge G v) (chainStart v c.injective)
      (chainGoal v c.injective) n (exteriorLabel G v lab) (sourcePieces (G := G) v lab) where
  finiteVertices := inferInstance
  simpleEdges := fun _ _ => inferInstance
  distinctPorts := by
    intro he
    have h0 := congrArg Subtype.val he
    have h1 := c.injective h0
    have h2 := congrArg Fin.val h1
    dsimp [chainStart, chainGoal] at h2
    omega
  noOldShortcut := fun e => c.noShortcut e.down
  internalPositive := c.positive
  chainLength := sourcePieces_length (G := G) v lab
  chainNonempty := sourcePieces_nonempty v c lab hne
  exteriorNonempty := fun e => hne e

def threeChainAdj (u w : Fin 3) : Prop := u.val + 1 = w.val

theorem threeChain_source : SourceChain threeChainAdj (fun i : Fin 3 => i) where
  injective := Function.injective_id
  positive := by decide
  edges := by intro i; rfl
  incoming := by
    intro i x hx
    apply Fin.ext
    unfold threeChainAdj chainInternal at hx
    dsimp at hx ⊢
    omega
  outgoing := by
    intro i y hy
    apply Fin.ext
    unfold threeChainAdj chainInternal at hy
    dsimp at hy ⊢
    omega
  noShortcut := by
    unfold threeChainAdj
    decide

theorem threeChain_nonempty_word :
    ∀ {u w : Fin 3} (e : PLift (threeChainAdj u w)),
      ([oneThird] : List Window) ≠ [] := by
  intro u w e
  simp

#print axioms source_fold_expand
#print axioms source_expand_fold
#print axioms sourceRawEquiv_trace
#print axioms sourceFoldEquiv_trace
#print axioms source_expansion_trace
#print axioms source_function_preserved
#print axioms source_prefix_budgets
#print axioms sourceRawEquiv_firstGoal
#print axioms sourceFoldEquiv_firstGoal
#print axioms source_executable_exists
#print axioms source_executable_class
#print axioms source_declared_accounting
#print axioms source_certified_interface
#print axioms threeChain_source
#print axioms threeChain_nonempty_word
end ClaimANormalForm

#print axioms ClaimA.suffix_empty_after
#print axioms ClaimA.final_source_macro_label
#print axioms ClaimANormalForm.sourceRawEquiv
#print axioms ClaimANormalForm.sourceFoldEquiv

namespace ClaimANormalForm
open ClaimA

def threeChainLabel {u w : Fin 3} (_e : PLift (threeChainAdj u w)) : List Window :=
  [oneThird]

def threeChainAggregates : DeclaredAggregates (@threeChainLabel) where
  cost := fun _ => 1 / 3
  span := fun _ => 1
  costChecked := by
    intro u w e
    simp [threeChainLabel, burden, oneThird]
  spanChecked := by
    intro u w e
    simp [threeChainLabel, duration, oneThird]

theorem threeChain_validated_instance :
    SourceChain threeChainAdj (fun i : Fin 3 => i) ∧
      (∀ {u w : Fin 3} (e : PLift (threeChainAdj u w)), threeChainLabel e ≠ []) ∧
      Nonempty (DeclaredAggregates (@threeChainLabel)) := by
  refine ⟨threeChain_source, ?_, ⟨threeChainAggregates⟩⟩
  intro u w e
  simp [threeChainLabel]

#print axioms threeChain_validated_instance
end ClaimANormalForm
